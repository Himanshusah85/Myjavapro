package Edu;

public class java {

}
